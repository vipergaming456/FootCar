FOOTCAR - PROGETTO ANDROID

Questo progetto avvolge il gioco HTML multiplayer in una WebView Android.
Richiede Android Studio e Android SDK 35 per generare l'APK.

COME GENERARE L'APK:
1. Estrai la cartella FootCarAndroid.
2. Apri Android Studio e scegli "Open", selezionando questa cartella.
3. Attendi la sincronizzazione Gradle e l'installazione dei componenti SDK richiesti.
4. Per provarlo: Run > Run 'app'.
5. Per creare un APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrerà il percorso dell'APK generato.

NOTE:
- Il multiplayer richiede una connessione Internet.
- Il gioco carica Three.js e PeerJS da CDN HTTPS.
- Il file APK non è stato compilato qui: serve Android Studio con Android SDK.
